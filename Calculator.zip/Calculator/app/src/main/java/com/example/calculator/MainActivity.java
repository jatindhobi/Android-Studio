package com.example.calculator;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    EditText editText1,editText2;
    TextView textView1;
    Button button1,button2,button3,button4;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        editText1=findViewById(R.id.myedit1);
        editText2=findViewById(R.id.myedit2);
        textView1=findViewById(R.id.myresult);
        button1=findViewById(R.id.mybtn1);
        button2=findViewById(R.id.mybtn2);
        button3=findViewById(R.id.mybtn3);
        button4=findViewById(R.id.mybtn4);

        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String str1=editText1.getText().toString().trim();
                String str2=editText2.getText().toString().trim();

                int num1=Integer.parseInt(str1);
                int num2=Integer.parseInt(str2);

                int result=num1+num2;

                textView1.setText(String.valueOf(result));
            }
        });

        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String str1=editText1.getText().toString().trim();
                String str2=editText2.getText().toString().trim();

                int num1=Integer.parseInt(str1);
                int num2=Integer.parseInt(str2);

                int result=num1-num2;

                textView1.setText(String.valueOf(result));
            }
        });

        button3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String str1=editText1.getText().toString().trim();
                String str2=editText2.getText().toString().trim();

                int num1=Integer.parseInt(str1);
                int num2=Integer.parseInt(str2);

                int result=num1*num2;

                textView1.setText(String.valueOf(result));
            }
        });

        button4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String str1=editText1.getText().toString().trim();
                String str2=editText2.getText().toString().trim();

                double num1=Integer.parseInt(str1);
                double num2=Integer.parseInt(str2);

                double result=num1/num2;

                textView1.setText(String.valueOf(result));
            }
        });
    }
}