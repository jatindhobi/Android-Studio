package com.example.recylerview;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity
{
    RecyclerView recyclerView;
    ArrayList<MyModel> data; // Declaration of the ArrayList
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView=findViewById(R.id.recycler);
        data=new ArrayList<>();
        data.add(new MyModel("Title","Description"));
        data.add(new MyModel("Title2","Description2"));
        data.add(new MyModel("Title3","Description3"));
        data.add(new MyModel("Title4","Description4"));
        data.add(new MyModel("Title5","Description5"));
        data.add(new MyModel("Title6","Description6"));
        data.add(new MyModel("Title7","Description7"));

        recyclerView.setAdapter(new MyAdapter(data,this));
        recyclerView.setLayoutManager(new LinearLayoutManager(MainActivity.this));
    }
}