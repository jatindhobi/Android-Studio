package com.example.recylerview;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import org.w3c.dom.Text;

import java.util.ArrayList;

public class MyAdapter extends RecyclerView.Adapter<MyAdapter.InnerClass> {
    ArrayList<MyModel> data;
    Context context;

    @NonNull
    @Override
    public InnerClass onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater=LayoutInflater.from(context);
        View view=inflater.inflate(R.layout.mycard,parent,false);
        return new InnerClass(view);
    }

    public MyAdapter(ArrayList<MyModel> data,Context context) {
        this.data = data;
        this.context=context;
    }

    @Override
    public void onBindViewHolder(@NonNull InnerClass holder, int position) {
        holder.bind(data.get(position));
    }

    @Override
    public int getItemCount() {
        return data.size();
    }

    public class InnerClass extends RecyclerView.ViewHolder{
        TextView textView1;
        TextView textView2;
        public InnerClass(@NonNull View itemView) {
            super(itemView);

            textView1=itemView.findViewById(R.id.my_txt1);
            textView2=itemView.findViewById(R.id.my_txt2);

        }

        public void bind(MyModel myModel) {
            textView1.setText(myModel.getTitle());
            textView2.setText(myModel.getDesc());
        }
    }
}
