package com.example.jump_one_activity_to_another_activity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class Dashboard extends AppCompatActivity {
    TextView textView1;
    Button button2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);
        textView1=findViewById(R.id.dummytext);
        button2=findViewById(R.id.showbtn);

        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String data=getIntent().getStringExtra("Mykey");
                textView1.setText(data);
            }
        });
    }
}